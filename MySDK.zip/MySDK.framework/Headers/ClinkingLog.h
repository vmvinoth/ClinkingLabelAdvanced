//
//  ClinkingLog.h
//  MySDK
//
//  Created by Vinoth on 11/4/17.
//  Copyright © 2017 Vinoth. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClinkingLog : NSObject
+(void)printToLog:(NSString*)str;
@end
